package decorator;

public interface Component {
	
	public String getName();
	
}