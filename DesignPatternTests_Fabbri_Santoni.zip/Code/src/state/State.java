package state;

public interface State {
	public int writeOutput(StateContext stateContext);
}
