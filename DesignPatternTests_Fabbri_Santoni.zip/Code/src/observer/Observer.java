package observer;

interface Observer { 
	public void update(Subject o);
}