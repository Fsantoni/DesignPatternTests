package composite;

public class CompositeException extends Exception {
	static final long serialVersionUID = 1;
	
	
	 public CompositeException(String message) {
	        super(message);
	    }

}
