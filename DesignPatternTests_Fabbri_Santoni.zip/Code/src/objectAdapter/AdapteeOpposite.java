package objectAdapter;


public class AdapteeOpposite extends Adaptee{
	
		

	public boolean getBooleanResult(){
		return !current;
	};

}
