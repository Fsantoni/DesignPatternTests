package classAdapter;

public interface Target {
	
	public int getIntResult();
	public void setIntResult(int newVal);

}
