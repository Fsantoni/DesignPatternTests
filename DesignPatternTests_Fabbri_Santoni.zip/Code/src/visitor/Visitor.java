package visitor;

public interface Visitor {
	public void visit();
}
