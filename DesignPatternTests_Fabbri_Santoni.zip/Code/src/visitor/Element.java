package visitor;

public interface Element {
	public void accept( ConcreteVisitor visitor ) ;
}
